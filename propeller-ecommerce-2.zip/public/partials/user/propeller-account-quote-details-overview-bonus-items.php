<!-- <div class="order-bonus-wrapper">
    <div class="row align-items-start">
        <div class="col mr-auto order-header">
            <h5><?php echo __('Bonus items!', 'propeller-ecommerce'); ?></h5>
        </div>
    </div>
    <div class="order-bonus-item">
        <div class="row align-items-start">
            <div class="col-2 col-md-1 order-bonus-image">							
                <a href="#">											
                    <img class="img-fluid" 
                        src="https://image.rightclick.nl/dev.cloud2.helice.cloud/files/07/D8/6ED71D0F5BC8-800x800-white.jpg" 
                        alt="bonus">
                </a>
            </div>
            <div class="col-10 col-md-4 col-lg-5 order-bonus-description">
                <div class="order-bonus-productname">name</div>
                <div class="order-bonus-productcode">
                <?php echo __('SKU', ''); ?>: 123456
                </div>  
            </div>
        
            <div class="col-1 col-md-1 ml-auto order-bonus-quantity">
                <div class="product-quantity no-input">
                    1
                </div>
            </div>
            <div class="col-3 col-md-2 order-bonus-price">
                <div class="order-bonus-total"><span class="symbol">&euro;&nbsp;</span> 0,00</div>
            </div>
            <div class="col-3 col-md-2 order-bonus-status">
            
            </div>
        </div>
    </div>
</div> -->
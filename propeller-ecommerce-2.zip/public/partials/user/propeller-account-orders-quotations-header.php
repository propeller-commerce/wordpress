<div class="row d-none d-md-flex orders-header no-gutters">                            
    <div class="col-md-2 col-xl-2"><?php echo __('Order number', 'propeller-ecommerce'); ?></div>
    <div class="col-md-2"><?php echo __('Date', 'propeller-ecommerce'); ?></div>
    <div class="col-xl-2 col-md-2"><?php echo __('Quantity', 'propeller-ecommerce'); ?></div>
    <div class="col-md-2"><?php echo __('Order total', 'propeller-ecommerce'); ?></div>
    <div class="col-md-2"><?php echo __('Status', 'propeller-ecommerce'); ?></div>        
</div>
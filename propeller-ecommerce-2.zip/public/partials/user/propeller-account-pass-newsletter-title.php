<div class="col-12">
    <h5><?php echo $title; ?></h5>
</div>
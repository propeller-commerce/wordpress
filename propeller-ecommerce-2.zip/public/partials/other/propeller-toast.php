<div id="propel_toast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true" data-delay="4000">
    <div class="toast-header">
      <div class="propel-toast-body"><?php echo __('Propeller', 'propeller-ecommerce'); ?></div>
      <button type="button" class="close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
</div>
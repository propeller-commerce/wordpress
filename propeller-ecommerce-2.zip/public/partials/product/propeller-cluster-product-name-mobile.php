<div class="product-meta d-flex d-md-none">
    <span class="product-category">(<?= $cluster_product->name[0]->value; ?>)</span>
</div>
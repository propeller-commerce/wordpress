<h1 class="product-name d-none d-md-flex">
    <?= $product->name[0]->value; ?>
</h1>
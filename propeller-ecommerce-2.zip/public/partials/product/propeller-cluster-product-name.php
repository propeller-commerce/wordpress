<div class="product-meta d-none d-md-flex">
    <span class="product-category">(<?= $cluster_product->name[0]->value; ?>)</span>
</div>
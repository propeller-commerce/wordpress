<div class="row form-group form-group-submit">
    <div class="col-form-fields col-12">
        <div class="form-row">
            <div class="col-12">
                <button type="submit" class="btn-proceed btn-green"><?php echo __('Choose payment method', 'propeller-ecommerce'); ?></button>
            </div>
        </div>
    </div>
</div>
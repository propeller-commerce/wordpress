<?php
namespace Propeller\Includes\Enum;

class ClusterDrillDownType {
    const RADIO = 'radio';
    const DROPDOWN = 'dropdown';
    const IMAGE = 'image';
    const COLOR = 'color';
}
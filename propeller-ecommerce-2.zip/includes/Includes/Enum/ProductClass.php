<?php
namespace Propeller\Includes\Enum;

class ProductClass {
    const Product = 'product';
    const Cluster = 'cluster';
}
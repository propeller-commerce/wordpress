<?php
namespace Propeller\Includes\Enum;

class MediaImagesType {
    const SMALL = 'small';
    const MEDIUM = 'medium';
    const LARGE = 'large';
}
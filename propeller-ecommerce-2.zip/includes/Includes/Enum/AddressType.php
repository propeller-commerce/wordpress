<?php
namespace Propeller\Includes\Enum;

class AddressType {
    const DELIVERY = 'delivery';
    const INVOICE = 'invoice';
}
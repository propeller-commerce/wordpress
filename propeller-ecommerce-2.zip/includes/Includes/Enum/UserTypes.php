<?php
namespace Propeller\Includes\Enum;

class UserTypes {
    const USER = 'User';
    const CUSTOMER = 'Customer';
    const CONTACT = 'Contact';
}
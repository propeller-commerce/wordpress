<?php
namespace Propeller\Includes\Enum;

class SortOrder {
    const ASC = 'asc';
    const DESC = 'desc';
}
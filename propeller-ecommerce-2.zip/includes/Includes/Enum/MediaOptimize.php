<?php
namespace Propeller\Includes\Enum;

class MediaOptimize {
    const LOW = 'LOW';
    const MEDIUM = 'MEDIUM';
    const HIGH = 'HIGH';
}
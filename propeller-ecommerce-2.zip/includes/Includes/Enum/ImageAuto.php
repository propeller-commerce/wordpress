<?php
namespace Propeller\Includes\Enum;

class ImageAuto {
    const WEBP = 'WEBP';
}
<?php
    namespace Propeller\Custom;

    class Custom {

    }
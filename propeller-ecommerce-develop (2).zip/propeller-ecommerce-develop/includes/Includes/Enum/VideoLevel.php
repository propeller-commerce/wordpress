<?php
namespace Propeller\Includes\Enum;

class ImageFit {
    const LEVEL_1_0 = 'LEVEL_1_0';
    const LEVEL_1_1 = 'LEVEL_1_1';
    const LEVEL_1_2 = 'LEVEL_1_2';

    const LEVEL_2_0 = 'LEVEL_2_0';
    const LEVEL_2_1 = 'LEVEL_2_1';
    const LEVEL_2_2 = 'LEVEL_2_2';

    const LEVEL_3_0 = 'LEVEL_3_0';
    const LEVEL_3_1 = 'LEVEL_3_1';
    const LEVEL_3_2 = 'LEVEL_3_2';

    const LEVEL_4_0 = 'LEVEL_4_0';
    const LEVEL_4_1 = 'LEVEL_4_1';
    const LEVEL_4_2 = 'LEVEL_4_2';

    const LEVEL_5_0 = 'LEVEL_5_0';
    const LEVEL_5_1 = 'LEVEL_5_1';
    const LEVEL_5_2 = 'LEVEL_5_2';

    const LEVEL_6_0 = 'LEVEL_6_0';
    const LEVEL_6_1 = 'LEVEL_6_1';
    const LEVEL_6_2 = 'LEVEL_6_2';
}
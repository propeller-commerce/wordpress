<?php
namespace Propeller\Includes\Enum;

class ImageFit {
    const BOUNDS = 'BOUNDS';
    const COVER = 'COVER';
    const CROP = 'CROP';
}
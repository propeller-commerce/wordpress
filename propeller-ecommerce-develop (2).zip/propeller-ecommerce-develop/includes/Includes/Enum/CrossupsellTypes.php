<?php
namespace Propeller\Includes\Enum;

class CrossupsellTypes {
    const ACCESSORIES = 'ACCESSORIES';
    const ALTERNATIVES = 'ALTERNATIVES';
    const OPTIONS = 'OPTIONS';
    const PARTS = 'PARTS';
    const RELATED = 'RELATED';
}
<?php
namespace Propeller\Includes\Enum;

class ImageSort {
    const ASC = 'ASC';
    const DESC = 'DESC';
}
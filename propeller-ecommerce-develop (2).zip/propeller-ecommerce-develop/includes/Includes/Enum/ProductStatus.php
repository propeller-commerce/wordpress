<?php
namespace Propeller\Includes\Enum;

class ProductStatus {
    const A = 'A';
    const N = 'N';
    const P = 'P';
    const S = 'S';
    const R = 'R';
}
<?php
namespace Propeller\Includes\Enum;

class TransactionStatuses {
    const FAILED = 'FAILED';
    const OPEN = 'OPEN';
    const PENDING = 'PENDING';
    const SUCCESS = 'SUCCESS';
}
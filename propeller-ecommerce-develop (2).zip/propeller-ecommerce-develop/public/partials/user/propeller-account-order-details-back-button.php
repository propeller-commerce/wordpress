<div class="back-link">
    <button onclick="history.back();">
        <svg class="icon icon-svg icon-arrow-left" aria-hidden="true">
            <use class="icon-shape-arrow-left" xlink:href="#shape-arrow-left"></use>
        </svg>
        <?php echo __('Back to order overview', 'propeller-ecommerce'); ?>
    </button>
</div>
               
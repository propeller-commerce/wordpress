<div class="col-12 d-none d-md-flex">
    <h1>
        <?= $title ?>
    </h1>
</div>
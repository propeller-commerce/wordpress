<div class="order-headers d-none d-md-flex">
    <div class="row w-100 align-items-center">
        <div class="col-md-6 description">
            <?php echo __('Products', 'propeller-ecommerce'); ?>
        </div>
        <!--<div class="col-md-2 reference">
                <?php echo __('Reference', 'propeller-ecommerce'); ?>
        </div> -->
        <div class="col-md-2 quantity">
            <?php echo __('Quantity', 'propeller-ecommerce'); ?>
        </div>
        <div class="col-md-2 price-per-item">
            <?php echo __('Price', 'propeller-ecommerce'); ?>
        </div>
        <div class="col-md-2 order-status">
            <?php echo __('Status', 'propeller-ecommerce'); ?>
        </div>
    </div>
</div>
<div class="row align-items-center">
    <div class="col-6">
        <div class="checkout-step"><?php echo __('Step 2', 'propeller-ecommerce'); ?></div>
        <div class="checkout-title"><?php echo __('Delivery details', 'propeller-ecommerce'); ?></div>
    </div>
    <div class="col-6 d-flex justify-content-end">
        <div class="checkout-step-nr">2/3</div>
    </div>
</div>
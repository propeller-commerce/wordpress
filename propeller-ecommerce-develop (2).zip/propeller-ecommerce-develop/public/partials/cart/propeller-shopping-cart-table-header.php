<div class="container-fluid px-0">
    <div class="row no-gutters shopping-cart-headers align-items-center">
        <div class="col-md-5 col-lg-7 description d-none d-md-flex">
            <?php echo __('Products', 'propeller-ecommerce'); ?>
        </div>
        <!-- <div class="col-md-2 reference">
            <?php echo __('Reference', 'propeller-ecommerce'); ?>
        </div> -->
        <div class="col-md-2 col-lg-2 price-per-item d-none d-md-flex">
            <?php echo __('Price per piece', 'propeller-ecommerce'); ?>
        </div>
        <div class="col-md-2 col-lg-1 quantity d-none d-md-flex">
            <?php echo __('Quantity', 'propeller-ecommerce'); ?>
        </div>
        <div class="col-md-2 price-total d-none d-md-flex">
            <?php echo __('Price', 'propeller-ecommerce'); ?>
        </div>
    </div>
</div>
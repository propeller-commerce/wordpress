<div class="row align-items-start">
    <div class="col mr-auto checkout-header">
        <h5><?php echo __('Bonus items', 'propeller-ecommerce'); ?></h5>
    </div>
</div>
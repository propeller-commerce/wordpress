<div class="row align-items-start">
    <div class="col-12 col-sm mr-auto checkout-header">
        <h1><?php echo __('Shopping cart', 'propeller-ecommerce'); ?></h1>
    </div>
</div>
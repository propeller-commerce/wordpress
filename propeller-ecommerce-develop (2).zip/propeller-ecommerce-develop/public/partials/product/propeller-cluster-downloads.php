<div id="pane-downloads" class="product-pane">
    <div class="row">
        <div class="col-12">
            <h3><?php echo __('Downloads', 'propeller-ecommerce'); ?></h3>
        </div>
        <div class="col-12">
            [Tab Downloads]
        </div>
    </div>
</div>
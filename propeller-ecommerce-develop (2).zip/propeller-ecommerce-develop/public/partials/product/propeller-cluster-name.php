<h1 class="product-name d-none d-md-flex">
    <?= $cluster->name[0]->value; ?>
</h1>
<div id="pane-video" class="product-pane">
    <div class="row">
        <div class="col-12">
            <h3><?php echo __("Videos", ''); ?></h3>
        </div>
        <div class="col-12">
            [Tab Video]
        </div>
    </div>
</div>   
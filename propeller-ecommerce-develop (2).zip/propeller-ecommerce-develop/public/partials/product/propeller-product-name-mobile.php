<h1 class="product-name d-block d-md-none">
    <?= $product->name[0]->value; ?>
</h1>
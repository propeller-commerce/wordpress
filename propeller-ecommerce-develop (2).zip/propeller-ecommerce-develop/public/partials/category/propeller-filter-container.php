<div class="filter-container">
    <?php $filters->draw(); ?>
</div>